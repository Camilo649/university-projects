///////////////////////////////////////////////////////////////////////////////
//
//	Simple example program demonstrating how to use a fragment shader using 
//	Cg. The shader modifies the gamma of a loaded image.
//
//	Gordon Wetzstein [wetzste1@cs.ubc.ca]
//	PSM Lab, University of British Columbia
//	March, 2009
//
///////////////////////////////////////////////////////////////////////////////
// includes

#include <stdio.h>
#include <iostream>
using namespace std;

// GL includes
#include <GL/glew.h>
#include <GL/glut.h>

// Cg includes
#include <Cg/cg.h>
#include <Cg/cgGL.h>

///////////////////////////////////////////////////////////////////////////////
// Cg parameter

// Cg context
CGcontext	_cgContext;
//	Cg profile for the fragment shader
CGprofile	_cgFragmentProfile;
//	Cg program for testing the performance
CGprogram	_cgProgram;
// gamma parameter
CGparameter	_cgGamma;
// Cg texture
CGparameter	_cgTexture;

// CPU gamma parameter
float		_gamma = 1.0;
float		_gammaStep = 0.05;

// just indicates if shader is initialized
bool		_bShaderInitialized = false;

// load the shader 
bool		loadShader(void);
// destroy all Cg related stuff
void		destroyShader(void);

///////////////////////////////////////////////////////////////////////////////
// GLUT callbacks and functions

// initialize glut window
void initGlut(int argc, char **argv);
// display callback
void displayFunc(void);
// idle callback
void idleFunc(void);
// reshape window callback
void reshapeFunc(int width, int height);
// keyboard callback
void keyboardFunc(unsigned char key, int x, int y);
// callback for arrow keys
void specialFunc(int key, int x, int y);

///////////////////////////////////////////////////////////////////////////////
// frame counter

void countFrames(void);
void renderBitmapString(float x, float y, float z, void *font, char *string);

// parameters for the framecounter
char pixelstring[256];
int cframe = 0;
int time_ = 0;
int timebase = 0;
float timestep = 0;
///////////////////////////////////////////////////////////////////////////////
// some other parameters

bool	bFullsreen = false;
int		nWindowID;

// texture ID for image
GLuint	_textureID;
int		_textureSize[2];

// load image from file and upload on as texture on GPU
bool	loadPPM(char *filename);

///////////////////////////////////////////////////////////////////////////////

void displayFunc(void) {

	GLenum err;

	// initialize shader
	if(!_bShaderInitialized) {

		// load image
		_bShaderInitialized = loadPPM("test.ppm");

		// load shader from .cg file
		if(_bShaderInitialized) {
			_bShaderInitialized = loadShader();
		}
		
		// check for errors
		err = glGetError();
		if(err != GL_NO_ERROR)
			printf("OpenGL ERROR after shader initialization: %s\n", gluErrorString(err));
	}

	//////////////////////////////////////////////////////////////////////////

	if(_bShaderInitialized) {

		// draw result
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		glMatrixMode(GL_PROJECTION);
		glPushMatrix();
		glLoadIdentity();
		gluOrtho2D(0.0, 1.0, 0.0, 1.0);

		glMatrixMode(GL_MODELVIEW);	
		glPushMatrix();
		glLoadIdentity();

		// bind image texture
		glEnable(GL_TEXTURE_RECTANGLE_ARB);
		glBindTexture(GL_TEXTURE_RECTANGLE_ARB,_textureID);

		// disable depth dest, just in case
		glDisable(GL_DEPTH_TEST);

		// enable shader and set parameters
		cgGLEnableProfile( _cgFragmentProfile );
		cgGLBindProgram( _cgProgram );

		// set Cg texture
		cgGLSetTextureParameter(_cgTexture, _textureID);
		cgGLEnableTextureParameter(_cgTexture);
		
		// set gamma
		cgGLSetParameter1f(_cgGamma, _gamma);

		// draw quad textured with image
		glBegin(GL_QUADS);
			glTexCoord2i(0, 0);								glVertex2f(0.0, 1.0);
			glTexCoord2i(_textureSize[0], 0);				glVertex2f(1.0, 1.0);
			glTexCoord2i(_textureSize[0], _textureSize[1]);	glVertex2f(1.0, 0.0);
			glTexCoord2i(0, _textureSize[1]);				glVertex2f(0.0, 0.0);
		glEnd();

		// disable Cg texture and profile
		cgGLDisableTextureParameter(_cgTexture);
		cgGLDisableProfile( _cgFragmentProfile );
	
		glPopMatrix();
		glMatrixMode(GL_PROJECTION);
		glPopMatrix();

		// framecounter
		countFrames();
	
		// check for errors
		err = glGetError();
		if(err != GL_NO_ERROR)
			printf("OpenGL ERROR: %s\n", gluErrorString(err));
	
		glutSwapBuffers();
	
	}
}

///////////////////////////////////////////////////////////////////////////////

void initGlut(int argc, char **argv) {

	// GLUT Window Initialization:
	glutInit (&argc, argv);
	glutInitWindowSize (640, 480);
	glutInitWindowPosition(200, 100);
	glutInitDisplayMode ( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH );
	nWindowID = glutCreateWindow ("CS 314 CgExample Fragment Shader");

	// initialize glew
	GLenum err = glewInit();
	if (GLEW_OK != err)
		cout << "ERROR: could not initialize GLEW!" << endl;

	// register callbacks
	glutDisplayFunc		(displayFunc);
	glutReshapeFunc		(reshapeFunc);
	glutKeyboardFunc	(keyboardFunc);
	glutSpecialFunc		(specialFunc);
	glutIdleFunc		(idleFunc);
}

///////////////////////////////////////////////////////////////////////////////

bool	
loadShader(void) {

	/////////////////////////////////////////////////////////////////////
	// init fragment shader profile

	_cgFragmentProfile = cgGLGetLatestProfile(CG_GL_FRAGMENT);

	/////////////////////////////////////////////////////////////////////
	// init context

	if(!_cgContext)
		_cgContext = cgCreateContext();

	/////////////////////////////////////////////////////////////////////
	//	init shader

	_cgProgram = cgCreateProgramFromFile(	_cgContext,
											CG_SOURCE,
											"GammaMappingShader.cg",
											_cgFragmentProfile,
											NULL,
											NULL );

	cgGLLoadProgram( _cgProgram );
	_cgTexture	= cgGetNamedParameter(_cgProgram, "texture");
	_cgGamma	= cgGetNamedParameter(_cgProgram, "gamma");

	/////////////////////////////////////////////////////////////////////
	// check for errors

	GLenum error = glGetError();
	if(error != GL_NO_ERROR) {
		cout << "GL ERROR: " << gluErrorString(error) << endl;
		return false;
	}

	if(CGerror cgError = cgGetError()) {
		cout << "Cg ERROR: " << cgGetErrorString(cgError) << endl;
		return false;
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////

void
destroyShader(void) {
	if(_bShaderInitialized) {
		cgDestroyProgram(_cgProgram);
	}
}

///////////////////////////////////////////////////////////////////////////////

void
idleFunc(void) {
	glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////////////////

void
reshapeFunc(int width, int height) {
	glViewport(0, 0, width, height);
}

///////////////////////////////////////////////////////////////////////////////

void 
keyboardFunc(unsigned char key, int x, int y) {

	switch(key) {
		
		// -----------------------------------------

#ifdef WIN32
		// exit on escape
		case '\033':
			
			// destroy shader and free other resources
			if(_bShaderInitialized) {
			
				glDeleteTextures(1, &_textureID);

				destroyShader();
				_bShaderInitialized = false;
			}
			exit(0);
			break;
#endif

		////////////////////////////////////////////
		// toggle fullscreen
		case 'f':

			bFullsreen = !bFullsreen;
			if(bFullsreen)
				glutFullScreen();
			else {
				glutSetWindow(nWindowID);
				glutPositionWindow(200, 100);
				glutReshapeWindow(640, 480);
			}
			break;
	}
}

///////////////////////////////////////////////////////////////////////////////

void specialFunc(int key, int x, int y) {
	if(key == GLUT_KEY_UP) {
		_gamma += _gammaStep;
	} else if(key == GLUT_KEY_DOWN) {
		_gamma = ((_gamma-_gammaStep)>=0) ? _gamma-_gammaStep : _gamma;
	}
}

///////////////////////////////////////////////////////////////////////////////

void countFrames(void)  {

	time_=glutGet(GLUT_ELAPSED_TIME);
	timestep = (time_-timebase)/1000.0;
	cframe++;
	if (time_ - timebase > 50) {
		sprintf(pixelstring, "gamma: %4.2f | fps: %4.2f", _gamma, cframe*1000.0/(time_-timebase));
		timebase = time_;
		cframe = 0;
	}

	glutSetWindowTitle(pixelstring);
}

///////////////////////////////////////////////////////////////////////////////

void renderBitmapString(float x, float y, float z, void *font, char *string) {
  char *c;
  glRasterPos3f(x, y,z);
  for (c=string; *c != '\0'; c++) {
    glutBitmapCharacter(font, *c);
  }
}

///////////////////////////////////////////////////////////////////////////////

bool
loadPPM(char *filename) {

	// image buffer
	unsigned char *imageData = NULL;

	// open file
	FILE *fp;

	if ((fp=fopen (filename, "rb"))==NULL) {
		cout << "ERROR: unable to open file " << filename << endl;
		return false;
    }

	char buffer[100];

	// read file identifier (magic number)
	fgets (buffer, sizeof (buffer), fp);	
	if ((buffer[0] != 'P') || (buffer[1] != '6'))  {
		cout << "ERROR: incorrect file type" << endl;
		return false;
    }

	// read comments
	do
		fgets (buffer, sizeof (buffer), fp);
	while (buffer[0] == '#');

	// load image size
	sscanf (buffer, "%d %d", &_textureSize[0], &_textureSize[1]);

	if( (_textureSize[0]==0) || (_textureSize[1]==0) ) {
		cout << "ERROR: make sure the ppm image header options are separated by newlines!" << endl;
		return false;
	}

	// read maximum pixel value (usually 255)
	do
		fgets (buffer, sizeof (buffer), fp);
	while (buffer[0] == '#');

	int maxval;
	sscanf (buffer, "%d", &maxval);

	int imageChannels = 3;
	imageData = new unsigned char[_textureSize[0]*_textureSize[1]*imageChannels];

	// read RGB data and calculate alpha value
	for (int i=0; i < _textureSize[0]*_textureSize[1]*imageChannels; i++)
    {
		char c=fgetc(fp);
        imageData[i]=(unsigned char)c;
    }

	// close input file
	fclose(fp);

	//////////////////////////////////////////////////////////////////////////
	// initialze OpenGL texture		
	glEnable(GL_TEXTURE_RECTANGLE_ARB);

	// generate texture
	glGenTextures(1, &_textureID);
	glBindTexture(GL_TEXTURE_RECTANGLE_ARB, _textureID);

	// set texture parameter
	glTexParameterf(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_S, GL_CLAMP_TO_EDGE);
	glTexParameterf(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_WRAP_T, GL_CLAMP_TO_EDGE);
	glTexParameterf(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
	glTexParameterf(GL_TEXTURE_RECTANGLE_ARB, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);

	if(imageData) {
		glTexImage2D(GL_TEXTURE_RECTANGLE_ARB, 0, GL_RGB, _textureSize[0], _textureSize[1], 0, GL_RGB, GL_UNSIGNED_BYTE, imageData);
		delete [] imageData;
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////

int
main(int argc, char **argv) {
	
	initGlut(argc, argv);

	cout << "Simple Cg fragment shader example." << endl;
	cout << "Gordon Wetzstein [wetzste1@cs.ubc.ca]" << endl << endl;

	cout << "keys:	Esc			- terminate program" << endl;
	cout << "		arrow up	- increase gamma" << endl;
	cout << "		arrow down	- decrease gamma" << endl << endl;

	cout << "OpenGL version: " << glGetString(GL_VERSION) << endl;
	cout << "OpenGL vendor: " << glGetString(GL_VENDOR) << endl;
	cout << "OpenGL renderer: " << glGetString(GL_RENDERER) << endl << endl;

	// hand over to glut
	glutMainLoop();
		
}

///////////////////////////////////////////////////////////////////////////////


