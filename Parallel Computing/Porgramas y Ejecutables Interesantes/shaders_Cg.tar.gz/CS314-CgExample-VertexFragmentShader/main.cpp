///////////////////////////////////////////////////////////////////////////////
//
//	Simple example program demonstrating how to use a vertex shader and a 
//	fragment shader simultaneously. This example implements Phong (per-pixel)
//	shading.
//
//	Gordon Wetzstein [wetzste1@cs.ubc.ca]
//	PSM Lab, University of British Columbia
//	March, 2009
//
///////////////////////////////////////////////////////////////////////////////
// includes

#include <stdio.h>
#include <iostream>
using namespace std;

// GL includes
#include <GL/glew.h>
#include <GL/glut.h>

// Cg includes
#include <Cg/cg.h>
#include <Cg/cgGL.h>

///////////////////////////////////////////////////////////////////////////////
// GLUT callbacks and functions

// initialize glut window
void initGlut(int argc, char **argv);
// display callback
void displayFunc(void);
// idle callback
void idleFunc(void);
// reshape window callback
void reshapeFunc(int width, int height);
// mouse callback
void mouseFunc(int button, int state, int x, int y);
// mouse motion callback
void mouseMotionFunc(int x, int y);
// keyboard callback
void keyboardFunc(unsigned char key, int x, int y);
// callback for arrow keys
void specialFunc(int key, int x, int y);

///////////////////////////////////////////////////////////////////////////////
// Cg parameter

// Cg context
CGcontext	_cgContext;
//	Cg profile for the fragment shader
CGprofile	_cgFragmentProfile;
//	Cg profile for the vertex shader
CGprofile	_cgVertexProfile;
//	Cg vertex program 
CGprogram	_cgVertexProgram;
//	Cg fragment program 
CGprogram	_cgFragmentProgram;
//	Cg vertex program for Gouraud shader
CGprogram	_cgVertexProgramGouraud;

// Cg parameter for light position
CGparameter _cgLightPosition;

// Cg parameters for material shininess
CGparameter _cgMaterialShininess;
CGparameter _cgMaterialShininessGouraud;
float		_materialShininess = 200;

// Cg parameters for modelview and projection matrix
CGparameter _cgModelviewMatrix;
CGparameter _cgModelviewMatrixIT;
CGparameter _cgProjectionMatrix;
CGparameter _cgObjectMatrix;
CGparameter _cgObjectMatrixIT;

// Cg parameters for modelview and projection matrix for Gouraud shader
CGparameter _cgLightPositionGouraud;
CGparameter _cgModelviewMatrixGouraud;
CGparameter _cgModelviewMatrixITGouraud;
CGparameter _cgProjectionMatrixGouraud;
CGparameter _cgObjectMatrixGouraud;
CGparameter _cgObjectMatrixITGouraud;

// toggle between shaders
bool		_bUsePhong = true;

// CPU variable for light position
float		_lightPosition[]	= { 5.0, 5.0, 10.0, 1.0 };

// just indicates if shader is initialized
bool		_bShaderInitialized = false;

// load the shader 
bool		loadShader(void);
// destroy all Cg related stuff
void		destroyShader(void);

///////////////////////////////////////////////////////////////////////////////
// frame counter

void countFrames(void);
void renderBitmapString(float x, float y, float z, void *font, char *string);

// parameters for the framecounter
char pixelstring[256];
int cframe = 0;
int time_ = 0;
int timebase = 0;
float timestep = 0;

///////////////////////////////////////////////////////////////////////////////
// some other parameters

bool	bFullsreen = false;
int		nWindowID;

float	_teapotScale = 10.0;

///////////////////////////////////////////////////////////////////////////////
// parameters for the navigation

// camera attributes
float viewerPosition[3]		= { 0.0, 0.0, -50.0 };
float viewerDirection[3]	= { 0.0, 0.0, 0.0 };
float viewerUp[3]			= { 0.0, 1.0, 0.0 };

// rotation values for the navigation
float navigationRotation[3]	= { 0.0, 0.0, 0.0 };

// position of the mouse when pressed
int mousePressedX = 0, mousePressedY = 0;
float lastXOffset = 0.0, lastYOffset = 0.0, lastZOffset = 0.0;
// mouse button states
int leftMouseButtonActive = 0, middleMouseButtonActive = 0, rightMouseButtonActive = 0;
// modifier state
int shiftActive = 0, altActive = 0, ctrlActive = 0;

///////////////////////////////////////////////////////////////////////////////

void displayFunc(void) {

	GLenum err;

	// initialize shader
	if(!_bShaderInitialized) {

		_bShaderInitialized = loadShader();
		
		// check for errors
		err = glGetError();
		if(err != GL_NO_ERROR)
			printf("OpenGL ERROR after shader initialization: %s\n", gluErrorString(err));
	}

	//////////////////////////////////////////////////////////////////////////

	// clear the buffers
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	// set up projection matrix
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	gluPerspective(50.0, 1.33, 0.01, 100.0);
	
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();

	glEnable(GL_LIGHTING);
	glEnable(GL_LIGHT0);

	glLightfv(GL_LIGHT0, GL_POSITION, _lightPosition);

	// add mouse navigation 
	glTranslatef( viewerPosition[0], viewerPosition[1], viewerPosition[2] );
	glRotatef( navigationRotation[0], 1.0f, 0.0f, 0.0f );
	glRotatef( navigationRotation[1], 0.0f, 1.0f, 0.0f );

	// enable the shader and set all the parameters

	if(_bShaderInitialized) {

		if(_bUsePhong) {

			//////////////////////////////////////////////////////////////////////////
			// enable vertex shader and set parameters
			cgGLEnableProfile( _cgVertexProfile );
			cgGLBindProgram( _cgVertexProgram );

			// set matrix parameters
			cgGLSetStateMatrixParameter(_cgModelviewMatrix, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_IDENTITY);
			cgGLSetStateMatrixParameter(_cgModelviewMatrixIT, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_INVERSE_TRANSPOSE);
			cgGLSetStateMatrixParameter(_cgProjectionMatrix, CG_GL_PROJECTION_MATRIX, CG_GL_MATRIX_IDENTITY);

			// set light and material parameters
			cgGLSetParameter3f(_cgLightPosition, _lightPosition[0], _lightPosition[1], _lightPosition[2]);
			cgGLSetParameter1f(_cgMaterialShininess, _materialShininess);

			// do some transformation that would be done in the glutSolidTeapot function
			// otherwise, need to include it in the modelview matrix
			glPushMatrix();
			glLoadIdentity();
			glRotatef(270.0, 1.0, 0.0, 0.0);
			glScalef(0.5*_teapotScale, 0.5*_teapotScale, 0.5*_teapotScale);
			glTranslatef(0.0, 0.0, -1.5);
			cgGLSetStateMatrixParameter(_cgObjectMatrix, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_IDENTITY);
			cgGLSetStateMatrixParameter(_cgObjectMatrixIT, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_INVERSE_TRANSPOSE);
			glPopMatrix();

			//////////////////////////////////////////////////////////////////////////
			// enable fragment shader and set parameters
			cgGLEnableProfile( _cgFragmentProfile );
			cgGLBindProgram( _cgFragmentProgram );

		} else {

			//////////////////////////////////////////////////////////////////////////
			// enable vertex shader and set parameters
			cgGLEnableProfile( _cgVertexProfile );
			cgGLBindProgram( _cgVertexProgramGouraud );

			// set matrix parameters
			cgGLSetStateMatrixParameter(_cgModelviewMatrixGouraud, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_IDENTITY);
			cgGLSetStateMatrixParameter(_cgModelviewMatrixITGouraud, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_INVERSE_TRANSPOSE);
			cgGLSetStateMatrixParameter(_cgProjectionMatrixGouraud, CG_GL_PROJECTION_MATRIX, CG_GL_MATRIX_IDENTITY);

			// set light and material parameters
			cgGLSetParameter3f(_cgLightPositionGouraud, _lightPosition[0], _lightPosition[1], _lightPosition[2]);
			cgGLSetParameter1f(_cgMaterialShininessGouraud, _materialShininess);

			// do some transformation that would be done in the glutSolidTeapot function
			// otherwise, need to include it in the modelview matrix
			glPushMatrix();
			glLoadIdentity();
			glRotatef(270.0, 1.0, 0.0, 0.0);
			glScalef(0.5*_teapotScale, 0.5*_teapotScale, 0.5*_teapotScale);
			glTranslatef(0.0, 0.0, -1.5);
			cgGLSetStateMatrixParameter(_cgObjectMatrixGouraud, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_IDENTITY);
			cgGLSetStateMatrixParameter(_cgObjectMatrixITGouraud, CG_GL_MODELVIEW_MATRIX, CG_GL_MATRIX_INVERSE_TRANSPOSE);
			glPopMatrix();

		}
	}

	//glutSolidTeapot(_teapotScale);
	glutSolidTorus(1.0, 2.0, 10, 10);

	if(_bShaderInitialized) {

		if(_bUsePhong) {
			// disable profiles
			cgGLDisableProfile( _cgVertexProfile  );
			cgGLDisableProfile( _cgFragmentProfile );
		} else {
			cgGLDisableProfile( _cgVertexProfile );
		}
	}

	// draw light source
	glDisable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glColor3f(1.0f, 1.0f, 1.0f);
	glTranslatef(_lightPosition[0], _lightPosition[1], _lightPosition[2]);
	glutSolidSphere(2.0, 50, 50);

	countFrames();
	glutSwapBuffers();
}

///////////////////////////////////////////////////////////////////////////////

void initGlut(int argc, char **argv) {

	// GLUT Window Initialization:
	glutInit (&argc, argv);
	glutInitWindowSize (640, 480);
	glutInitWindowPosition(100, 100);
	glutInitDisplayMode ( GLUT_RGBA | GLUT_DOUBLE | GLUT_DEPTH);
	nWindowID = glutCreateWindow ("CS 314 CgExample Vertex and Fragment Shader");

	// Register callbacks:
	glutDisplayFunc		(displayFunc);
	glutReshapeFunc		(reshapeFunc);
	glutKeyboardFunc	(keyboardFunc);
	glutMouseFunc		(mouseFunc);
	glutMotionFunc		(mouseMotionFunc);
	glutSpecialFunc		(specialFunc);
	glutIdleFunc		(idleFunc);
}

///////////////////////////////////////////////////////////////////////////////

void idleFunc(void) {
	glutPostRedisplay();
}

///////////////////////////////////////////////////////////////////////////////

void reshapeFunc(int width, int height) {
	glViewport(0, 0, width, height);
}

///////////////////////////////////////////////////////////////////////////////

// mouse callback
void mouseFunc(int button, int state, int x, int y) {
	
	// get the mouse buttons
	if (button == GLUT_LEFT_BUTTON)
		if (state == GLUT_DOWN) {
			leftMouseButtonActive += 1;
		} else
			leftMouseButtonActive -= 1;
	else if (button == GLUT_MIDDLE_BUTTON)
		if (state == GLUT_DOWN) {
			middleMouseButtonActive += 1;
			lastXOffset = 0.0;
			lastYOffset = 0.0;
		} else
			middleMouseButtonActive -= 1;
	else if (button == GLUT_RIGHT_BUTTON)
		if (state == GLUT_DOWN) {
			rightMouseButtonActive += 1;
			lastZOffset = 0.0;
		} else
			rightMouseButtonActive -= 1;

	mousePressedX = x;
	mousePressedY = y;
}

///////////////////////////////////////////////////////////////////////////////

void mouseMotionFunc(int x, int y) {
	
	float xOffset = 0.0, yOffset = 0.0, zOffset = 0.0;
	
	// rotatation
	if (leftMouseButtonActive) {

		navigationRotation[0] += ((mousePressedY - y) * 180.0f) / 200.0f;
		navigationRotation[1] += ((mousePressedX - x) * 180.0f) / 200.0f;

		mousePressedY = y;
		mousePressedX = x;

	}
	// panning
	else if (middleMouseButtonActive) {

		xOffset = (mousePressedX + x);
		if (!lastXOffset == 0.0) {
			viewerPosition[0]	-= (xOffset - lastXOffset) / 8.0;
			viewerDirection[0]	-= (xOffset - lastXOffset) / 8.0;
		}
		lastXOffset = xOffset;

		yOffset = (mousePressedY + y);
		if (!lastYOffset == 0.0) {
			viewerPosition[1]	+= (yOffset - lastYOffset) / 8.0;
			viewerDirection[1]	+= (yOffset - lastYOffset) / 8.0;
		}	
		lastYOffset = yOffset;

	}
	// depth movement
	else if (rightMouseButtonActive) {
		zOffset = (mousePressedX + x);
		if (!lastZOffset == 0.0) {
			viewerPosition[2] -= (zOffset - lastZOffset) / 5.0;
			viewerDirection[2] -= (zOffset - lastZOffset) / 5.0;
		}
		lastZOffset = zOffset;
	}
}

///////////////////////////////////////////////////////////////////////////////

void keyboardFunc(unsigned char key, int x, int y) {

	switch(key) {
		
		////////////////////////////////////////////

#ifdef WIN32
		// exit on escape
		case '\033':
			destroyShader();
			exit(0);
			break;
#endif

		////////////////////////////////////////////
			
		// switch to fullscreen
		case 'f':

			bFullsreen = !bFullsreen;
			if(bFullsreen) 
				glutFullScreen();
			else {
				glutSetWindow(nWindowID);
				glutPositionWindow(100, 100);
				glutReshapeWindow(640, 480);
			}
			break;

		////////////////////////////////////////////

		case ' ':
			_bUsePhong = !_bUsePhong;
			break;
	}
}

///////////////////////////////////////////////////////////////////////////////

void specialFunc(int key, int x, int y) {
	float shininessStep = 10;
	if(key == GLUT_KEY_UP) {
		_materialShininess += shininessStep;
	} else if(key == GLUT_KEY_DOWN) {
		_materialShininess = ((_materialShininess-shininessStep)>0) ? _materialShininess-shininessStep: _materialShininess;
	}
}

///////////////////////////////////////////////////////////////////////////////

void countFrames(void)  {

	time_=glutGet(GLUT_ELAPSED_TIME);
	cframe++;
	if (time_ - timebase > 50) {
		sprintf(pixelstring, "shininess: %4.2f | fps: %4.2f", _materialShininess, cframe*1000.0/(time_-timebase));
		timebase = time_;
		cframe = 0;
	}
	glutSetWindowTitle(pixelstring);
}

///////////////////////////////////////////////////////////////////////////////

void renderBitmapString(float x, float y, float z, void *font, char *string) {
  char *c;
  glRasterPos3f(x, y,z);
  for (c=string; *c != '\0'; c++) {
    glutBitmapCharacter(font, *c);
  }
}

///////////////////////////////////////////////////////////////////////////////

bool
loadShader(void) {

	/////////////////////////////////////////////////////////////////////
	// init context

	if(!_cgContext)
		_cgContext = cgCreateContext();

	/////////////////////////////////////////////////////////////////////
	// init shader profiles

	_cgVertexProfile	= cgGLGetLatestProfile(CG_GL_VERTEX);
	_cgFragmentProfile	= cgGLGetLatestProfile(CG_GL_FRAGMENT);

	/////////////////////////////////////////////////////////////////////
	//	init vertex shader

	_cgVertexProgram = cgCreateProgramFromFile(	_cgContext,
												CG_SOURCE,
												"VertexShaderPhong.cg",
												_cgVertexProfile,
												NULL,
												NULL );
	cgGLLoadProgram( _cgVertexProgram );

	// get all the parameters
	// matrix parameters
	_cgModelviewMatrix		= cgGetNamedParameter(_cgVertexProgram, "modelViewMatrix");
	_cgModelviewMatrixIT	= cgGetNamedParameter(_cgVertexProgram, "modelViewMatrixIT");
	_cgProjectionMatrix		= cgGetNamedParameter(_cgVertexProgram, "projectionMatrix");
	_cgObjectMatrix			= cgGetNamedParameter(_cgVertexProgram, "objectMatrix");
	_cgObjectMatrixIT		= cgGetNamedParameter(_cgVertexProgram, "objectMatrixIT");

	_cgLightPosition		= cgGetNamedParameter(_cgVertexProgram, "lightPosition");
	_cgMaterialShininess	= cgGetNamedParameter(_cgVertexProgram, "materialShininess");

	/////////////////////////////////////////////////////////////////////	
	//	init fragment shader

	_cgFragmentProgram = cgCreateProgramFromFile(	_cgContext,
													CG_SOURCE,
													"FragmentShaderPhong.cg",
													_cgFragmentProfile,
													NULL,
													NULL );
	cgGLLoadProgram( _cgFragmentProgram );

	/////////////////////////////////////////////////////////////////////
	//	init Gouraud vertex shader

	_cgVertexProgramGouraud = cgCreateProgramFromFile(	_cgContext,
														CG_SOURCE,
														"VertexShaderGouraud.cg",
														_cgVertexProfile,
														NULL,
														NULL );
	cgGLLoadProgram( _cgVertexProgramGouraud );

	// get all the parameters
	// matrix parameters
	_cgModelviewMatrixGouraud		= cgGetNamedParameter(_cgVertexProgramGouraud, "modelViewMatrix");
	_cgModelviewMatrixITGouraud		= cgGetNamedParameter(_cgVertexProgramGouraud, "modelViewMatrixIT");
	_cgProjectionMatrixGouraud		= cgGetNamedParameter(_cgVertexProgramGouraud, "projectionMatrix");
	_cgObjectMatrixGouraud			= cgGetNamedParameter(_cgVertexProgramGouraud, "objectMatrix");
	_cgObjectMatrixITGouraud		= cgGetNamedParameter(_cgVertexProgramGouraud, "objectMatrixIT");

	_cgLightPositionGouraud			= cgGetNamedParameter(_cgVertexProgramGouraud, "lightPosition");
	_cgMaterialShininessGouraud		= cgGetNamedParameter(_cgVertexProgramGouraud, "materialShininess");

	/////////////////////////////////////////////////////////////////////
	// check for errors

	GLenum error = glGetError();
	if(error != GL_NO_ERROR) {
		cout << "GL ERROR: " << gluErrorString(error) << endl;
		return false;
	}

	if(CGerror cgError = cgGetError()) {
		cout << "Cg ERROR: " << cgGetErrorString(cgError) << endl;
		return false;
	}

	return true;
}

///////////////////////////////////////////////////////////////////////////////

void		
destroyShader(void) {

	if(_bShaderInitialized) {
		cgDestroyProgram(_cgVertexProgram);
		cgDestroyProgram(_cgFragmentProgram);
		cgDestroyProgram(_cgVertexProgramGouraud);
	}
}

///////////////////////////////////////////////////////////////////////////////

int
main(int argc, char **argv) {
	
	initGlut(argc, argv);

	cout << "Simple Cg vertex and fragment shader example." << endl;
	cout << "Gordon Wetzstein [wetzste1@cs.ubc.ca]" << endl << endl;

	cout << "keys:	Esc         - terminate program" << endl;
	cout << "	Space       - switch between Phong and Gouraud shading" << endl;
	cout << "	Mouse Left  - rotation" << endl;
	cout << "	Mouse Right - zoom" << endl;
	cout << "	arrow up	- increase material shininess" << endl;
	cout << "	arrow down	- decrease material shininess" << endl << endl;

	cout << "OpenGL version: "	<< glGetString(GL_VERSION) << endl;
	cout << "OpenGL vendor: "	<< glGetString(GL_VENDOR) << endl;
	cout << "OpenGL renderer: " << glGetString(GL_RENDERER) << endl << endl;

	// hand over to glut
	glutMainLoop();
		
}

